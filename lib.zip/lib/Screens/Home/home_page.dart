import 'package:agrale/Screens/Home/home_screen.dart';
import 'package:agrale/Screens/Menu/menu_screen.dart';
import 'package:agrale/Screens/Search/search_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:cupertino_icons/cupertino_icons.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {

  static const List<Map<String, dynamic>> navBottomItems = [
    {
      "icon": Icons.home,
      "label": "Home",
    },
    {
      "icon": Icons.search,
      "label": "Consulta chassi",
    },
    {
      "icon": Icons.menu,
      "label": "Menu",
    },
  ];

  late TabController tabController;
  int currentPageIndex = 0;

  @override
  void initState() {
    super.initState();
    tabController = TabController(
      initialIndex: 0,
      length: navBottomItems.length,
      vsync: this,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        systemOverlayStyle: SystemUiOverlayStyle(
          statusBarColor: Colors.white
        ),
        title: Text(navBottomItems[tabController.index]['label'], style: TextStyle(color: Colors.black),),
        elevation: 0,
        backgroundColor: Colors.white,

      ),
      backgroundColor: Color(0xffF3f3ee),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(18.0),
          child: DefaultTabController(
            length: navBottomItems.length,
            child: SizedBox(
              height: MediaQuery.of(context).size.height,
              child: TabBarView(
                physics: const NeverScrollableScrollPhysics(),
                controller: tabController,
                children: [
                  HomeScreen(),
                  SearchScreen(),
                  MenuScreen(),
                ],
              ),
            ),
          ),
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: tabController.index,
        selectedItemColor: Colors.red,
        onTap: (index) {
          tabController.animateTo(index);
          //para atualizar barra de nav
          setState(() {});
        },
        items: [
          for(var navItem in navBottomItems)
            BottomNavigationBarItem(
              icon: Icon(navItem["icon"] as IconData),
              label: navItem["label"] as String,
            )
        ],
      )
    );
  }


}
